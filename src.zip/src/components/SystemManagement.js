// import React, { useState } from 'react';

// function SystemManagement() {
//   const [devices, setDevices] = useState([
//     { id: 'SM001', type: 'Smart Meter', status: 'Online', firmware: 'v3.2.1', lastUpdate: '2023-05-15' },
//     { id: 'GW002', type: 'Gateway', status: 'Online', firmware: 'v2.0.5', lastUpdate: '2023-06-01' },
//     { id: 'SM003', type: 'Smart Meter', status: 'Offline', firmware: 'v3.1.9', lastUpdate: '2023-04-20' }
//   ]);

//   const [selectedDevice, setSelectedDevice] = useState(null);

//   const updateFirmware = (id) => {
//     setDevices(devices.map(device => 
//       device.id === id ? { ...device, firmware: 'v3.2.2', lastUpdate: '2023-06-04' } : device
//     ));
//   };

//   const scheduleMaintenence = () => {
//     alert('Maintenance scheduled for selected device on 2023-06-15');
//   };

//   return (
//     <div className="system-management">
//       <h2>System Management</h2>
      
//       <div className="device-list">
//         <h3>Connected Devices</h3>
//         <table>
//           <thead>
//             <tr><th>ID</th><th>Type</th><th>Status</th><th>Firmware</th><th>Last Update</th></tr>
//           </thead>
//           <tbody>
//             {devices.map(device => (
//               <tr key={device.id} onClick={() => setSelectedDevice(device)}>
//                 <td>{device.id}</td>
//                 <td>{device.type}</td>
//                 <td>{device.status}</td>
//                 <td>{device.firmware}</td>
//                 <td>{device.lastUpdate}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       {selectedDevice && (
//         <div className="device-actions">
//           <h3>Device: {selectedDevice.id}</h3>
//           <button onClick={() => updateFirmware(selectedDevice.id)}>Update Firmware</button>
//           <button onClick={scheduleMaintenence}>Schedule Maintenance</button>
//         </div>
//       )}

//       <div className="system-health">
//         <h3>System Health</h3>
//         <ul>
//           <li>Devices Online: 80%</li>
//           <li>Network Latency: 45ms</li>
//           <li>Data Accuracy: 99.7%</li>
//         </ul>
//       </div>

//       <div className="updates">
//         <h3>Available Updates</h3>
//         <ul>
//           <li>Smart Meter Firmware v3.2.2 - Security patches</li>
//           <li>Gateway Firmware v2.1.0 - Performance improvements</li>
//         </ul>
//       </div>
//     </div>
//   );
// }

// export default SystemManagement;

import React, { useState } from 'react';
import { meterData } from '../data/meterData';

function SystemManagement() {
  const [devices, setDevices] = useState(meterData);
  const [selectedDevice, setSelectedDevice] = useState(null);

  const updateFirmware = (id, version) => {
    setDevices(devices.map(device => 
      device.id === id ? { ...device, firmware: version, lastUpdate: '2023-06-04' } : device
    ));
  };

  return (
    <div className="system-management">
      <h2>System Management</h2>
      
      <div className="device-management">
        <h3>Device Management</h3>
        <table>
          <thead>
            <tr><th>ID</th><th>Type</th><th>Status</th><th>Firmware</th><th>Last Update</th></tr>
          </thead>
          <tbody>
            {devices.map(device => (
              <tr key={device.id} onClick={() => setSelectedDevice(device)}>
                <td>{device.id}</td>
                <td>Smart Meter</td>
                <td>{device.status}</td>
                <td>{device.firmware || 'N/A'}</td>
                <td>{device.lastUpdate || 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedDevice && (
        <div className="device-actions">
          <h3>Device: {selectedDevice.id}</h3>
          <button onClick={() => updateFirmware(selectedDevice.id, 'v3.2.2')}>Update Firmware</button>
          <button onClick={() => alert(`Maintenance scheduled for ${selectedDevice.id} on 2023-06-15`)}>Schedule Maintenance</button>
          <button onClick={() => setSelectedDevice(null)}>Close</button>
        </div>
      )}

      <div className="system-health">
        <h3>System Health</h3>
        <ul>
          <li>Devices Online: 80%</li>
          <li>Network Latency: 45ms</li>
          <li>Data Accuracy: 99.7%</li>
          <li>Last System Update: 2023-05-20</li>
        </ul>
      </div>

      <div className="maintenance">
        <h3>Scheduled Maintenance</h3>
        <table>
          <thead>
            <tr><th>Date</th><th>Time</th><th>Region</th><th>Type</th></tr>
          </thead>
          <tbody>
            <tr><td>2023-06-10</td><td>22:00-06:00</td><td>Downtown</td><td>Grid Upgrade</td></tr>
            <tr><td>2023-06-18</td><td>10:00-14:00</td><td>SoMa</td><td>Meter Replacements</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default SystemManagement;