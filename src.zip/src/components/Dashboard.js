// import React, { useState, useEffect } from 'react';
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   ArcElement,
//   Title,
//   Tooltip,
//   Legend
// } from 'chart.js';
// import { Bar, Pie } from 'react-chartjs-2';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faBolt, faExclamationTriangle, faPlug } from '@fortawesome/free-solid-svg-icons';
// import { gsap } from 'gsap';

// // Register Chart.js components
// ChartJS.register(
//   CategoryScale,  // for Bar chart x-axis
//   LinearScale,   // for Bar chart y-axis
//   BarElement,   // for Bar chart
//   ArcElement,   // for Pie chart
//   Title,
//   Tooltip,
//   Legend
// );

// function Dashboard() {
//   const [stats, setStats] = useState({ totalUsage: 0, alerts: 0, connectedMeters: 0 });

//   useEffect(() => {
//     const targetStats = { totalUsage: 1250, alerts: 5, connectedMeters: 500 };
//     gsap.to(stats, { duration: 2, ...targetStats, ease: "power1.inOut", onUpdate: () => setStats({ ...stats }) });
//   }, []);

//   const barData = {
//     labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
//     datasets: [{
//       label: 'Weekly Usage',
//       data: [500, 650, 720, 850, 690, 420, 580],
//       backgroundColor: '#2196F3',
//       borderRadius: 6,
//       barThickness: 30
//     }]
//   };

//   const handleRegionSelect = (region) => {
//     console.log(`Selected region: ${region}`);
//   };

//   const barOptions = {
//     scales: {
//       y: { 
//         beginAtZero: true,
//         grid: { color: 'rgba(0, 0, 0, 0.1)' }
//       },
//       x: {
//         grid: { display: false }
//       }
//     },
//     plugins: {
//       legend: { display: false }
//     },
//     animation: {
//       duration: 1500,
//       easing: 'easeInOutQuart'
//     }
//   };

//   const pieData = {
//     labels: ['Residential', 'Commercial', 'Industrial'],
//     datasets: [{
//       data: [60, 30, 10],
//       backgroundColor: ['#4CAF50', '#FFC107', '#F44336'],
//       borderWidth: 0,
//       hoverOffset: 10
//     }]
//   };

//   const pieOptions = {
//     plugins: {
//       legend: {
//         position: 'right',
//         labels: { font: { size: 14 } }
//       }
//     },
//     animation: {
//       animateRotate: true,
//       animateScale: true,
//       duration: 1500,
//       easing: 'easeInOutBack'
//     }
//   };

//   return (
//     <div className="dashboard">
//       <h1 className="dashboard-title">Power Grid Overview</h1>
//       <div className="stats-grid">
//         <div className="stat-card glow-effect">
//           <FontAwesomeIcon icon={faBolt} className="icon-bounce" />
//           <h3>{Math.round(stats.totalUsage)} kWh</h3>
//           <p>Total Usage</p>
//         </div>
//         <div className="stat-card alert glow-effect">
//           <FontAwesomeIcon icon={faExclamationTriangle} className="icon-shake" />
//           <h3>{Math.round(stats.alerts)}</h3>
//           <p>Active Alerts</p>
//         </div>
//         <div className="stat-card glow-effect">
//           <FontAwesomeIcon icon={faPlug} className="icon-pulse" />
//           <h3>{Math.round(stats.connectedMeters)}</h3>
//           <p>Connected Meters</p>
//         </div>
//       </div>
//       <div className="chart-container">
//         <div className="chart zoom-on-hover">
//           <h4>Weekly Energy Consumption</h4>
//           <Bar data={barData} options={barOptions} />
//         </div>
//         <div className="chart zoom-on-hover">
//           <h4>Distribution by Sector</h4>
//           <Pie data={pieData} options={pieOptions} />
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Dashboard;


import React, { useState, useEffect, useCallback } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import Map from './Map';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function Dashboard() {
  const [stats, setStats] = useState({
    totalConsumption: 0,
    peakUsageTime: '',
    energyEfficiencyScore: 0,
    consumptionByRegion: {
      labels: ['Downtown', 'Suburbs', 'Industrial', 'Commercial'],
      datasets: [{
        label: 'Consumption (kWh)',
        data: [0, 0, 0, 0],
        backgroundColor: 'rgba(54, 162, 235, 0.6)'
      }]
    }
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Simulating an API call with setTimeout
        setTimeout(() => {
          setStats(prevStats => ({
            ...prevStats,
            totalConsumption: 145200,
            peakUsageTime: '2 PM - 6 PM',
            energyEfficiencyScore: 82,
            consumptionByRegion: {
              ...prevStats.consumptionByRegion,
              datasets: [{
                ...prevStats.consumptionByRegion.datasets[0],
                data: [42000, 35000, 68000, 53000]
              }]
            }
          }));
        }, 1000);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      }
    };

    fetchData();
  }, []);

  const handleRegionSelect = useCallback((region) => {
    console.log(`Selected region: ${region}`);
    // Add any additional logic for when a region is selected
  }, []);

  return (
    <div className="dashboard">
      <h2>Smart Grid Dashboard</h2>
      
      <div className="stats-container">
        <div className="stat-item">
          <h3>Total Consumption</h3>
          <p>{stats.totalConsumption.toLocaleString()} kWh</p>
        </div>
        <div className="stat-item">
          <h3>Peak Usage Time</h3>
          <p>{stats.peakUsageTime}</p>
        </div>
        <div className="stat-item">
          <h3>Energy Efficiency Score</h3>
          <p>{stats.energyEfficiencyScore}/100</p>
        </div>
      </div>

      <div className="chart-container">
        <h3>Consumption by Region</h3>
        <Bar 
          data={stats.consumptionByRegion} 
          options={{ maintainAspectRatio: false, height: 300 }} 
        />
      </div>

      <div className="map-container">
        <h3>Geographic Overview</h3>
        <Map onRegionSelect={handleRegionSelect} />
      </div>
    </div>
  );
}

export default Dashboard;

