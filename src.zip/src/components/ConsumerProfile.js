import React from 'react';
import { consumerData } from '../data/consumerData';

function ConsumerProfile({ meterId }) {
  const consumer = consumerData.find(c => c.meterId === meterId);

  return (
    <div className="consumer-profile">
      <h4>Consumer Profile</h4>
      <p>Name: {consumer.name}</p>
      <p>Contact: {consumer.contact}</p>
      <p>Address: {consumer.address}</p>
    </div>
  );
}

export default ConsumerProfile;