


// import React, { useState } from 'react';
// import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
// import MarkerClusterGroup from 'react-leaflet-markercluster';
// import L from 'leaflet';
// import 'leaflet/dist/leaflet.css';
// import 'react-leaflet-markercluster/dist/styles.min.css';
// import 'leaflet.heat';
// import { meterData } from '../data/meterData';

// // Fix Leaflet's default icon path issue
// delete L.Icon.Default.prototype._getIconUrl;
// L.Icon.Default.mergeOptions({
//   iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
//   iconUrl: require('leaflet/dist/images/marker-icon.png'),
//   shadowUrl: require('leaflet/dist/images/marker-shadow.png')
// });

// function HeatmapLayer({ points }) {
//   return null; // Removed the useMap hook from here
// }

// function Map({ onRegionSelect }) {
//   const [mapView, setMapView] = useState('markers');
//   const center = [37.7749, -122.4194]; // San Francisco

//   const points = meterData.map(meter => [
//     meter.location[0],
//     meter.location[1],
//     meter.usage || 5 // Default usage if not provided
//   ]);

//   return (
//     <div className="map-container">
//       <div className="map-controls">
//         <button onClick={() => setMapView('markers')}>Markers</button>
//         <button onClick={() => setMapView('heatmap')}>Heat Map</button>
//       </div>
//       <MapContainer 
//         center={center} 
//         zoom={13} 
//         style={{ height: '600px' }}
//       >
//         <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
//         {mapView === 'markers' ? (
//           <MarkerClusterGroup>
//             {meterData.map(meter => (
//               <CircleMarker
//                 key={meter.id}
//                 center={meter.location}
//                 radius={10}
//                 fillColor={meter.status === 'active' ? '#4CAF50' : '#F44336'}
//                 fillOpacity={0.8}
//                 stroke={false}
//                 eventHandlers={{ click: () => onRegionSelect(meter.region) }}
//               >
//                 <Popup>{meter.id} - {meter.status}</Popup>
//               </CircleMarker>
//             ))}
//           </MarkerClusterGroup>
//         ) : (
//           <HeatmapLayer points={points} />
//         )}
//       </MapContainer>
//     </div>
//   );
// }

// export default Map;


import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import MarkerClusterGroup from 'react-leaflet-markercluster';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'react-leaflet-markercluster/dist/styles.min.css';
import 'leaflet.heat';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import { meterData } from '../data/meterData';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

function HeatmapLayer({ points }) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    const heatLayer = L.heatLayer(points, { radius: 25 }).addTo(map);

    return () => {
      if (map && map.hasLayer(heatLayer)) {
        map.removeLayer(heatLayer);
      }
    };
  }, [map, points]);

  return null;
}

function Map({ onRegionSelect }) {
  const [mapView, setMapView] = useState('markers');
  const center = [37.7749, -122.4194]; // San Francisco

  const points = meterData.map(meter => [
    meter.location[0],
    meter.location[1],
    meter.usage || 5 // Default usage if not provided
  ]);

  return (
    <div className="map-container">
      <div className="map-controls">
        <button onClick={() => setMapView('markers')}>Markers</button>
        <button onClick={() => setMapView('heatmap')}>Heat Map</button>
      </div>
      <MapContainer 
        center={center} 
        zoom={13} 
        style={{ height: '600px' }}
        whenCreated={(map) => {
          L.control.scale().addTo(map);
        }}
      >
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' />
        {mapView === 'markers' ? (
          <MarkerClusterGroup>
            {meterData.map(meter => (
              <CircleMarker
                key={meter.id}
                center={meter.location}
                radius={10}
                fillColor={meter.status === 'active' ? '#4CAF50' : '#F44336'}
                fillOpacity={0.8}
                stroke={false}
                eventHandlers={{ click: () => onRegionSelect(meter.region) }}
              >
                <Popup>{meter.id} - {meter.status}</Popup>
              </CircleMarker>
            ))}
          </MarkerClusterGroup>
        ) : (
          <HeatmapLayer points={points} />
        )}
      </MapContainer>
    </div>
  );
}

export default Map;


