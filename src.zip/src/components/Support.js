// import React, { useState } from 'react';

// function Support() {
//   const [tickets, setTickets] = useState([
//     { id: 1, user: 'John Doe', issue: 'Bill discrepancy', status: 'Open' },
//     { id: 2, user: 'Jane Smith', issue: 'Power outage', status: 'In Progress' },
//     { id: 3, user: 'Bob Johnson', issue: 'Smart meter not responding', status: 'Resolved' }
//   ]);

//   const [newTicket, setNewTicket] = useState({ user: '', issue: '' });

//   const handleInputChange = (e) => {
//     setNewTicket({ ...newTicket, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const ticket = { ...newTicket, id: tickets.length + 1, status: 'Open' };
//     setTickets([...tickets, ticket]);
//     setNewTicket({ user: '', issue: '' });
//   };

//   return (
//     <div className="support">
//       <h2>Customer Support and Helpdesk</h2>
      
//       <div className="ticket-list">
//         <h3>Support Tickets</h3>
//         <table>
//           <thead>
//             <tr><th>ID</th><th>User</th><th>Issue</th><th>Status</th></tr>
//           </thead>
//           <tbody>
//             {tickets.map(ticket => (
//               <tr key={ticket.id}>
//                 <td>{ticket.id}</td>
//                 <td>{ticket.user}</td>
//                 <td>{ticket.issue}</td>
//                 <td>{ticket.status}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>

//       <div className="new-ticket">
//         <h3>Create New Ticket</h3>
//         <form onSubmit={handleSubmit}>
//           <input type="text" name="user" placeholder="User Name" value={newTicket.user} onChange={handleInputChange} required />
//           <input type="text" name="issue" placeholder="Issue Description" value={newTicket.issue} onChange={handleInputChange} required />
//           <button type="submit">Submit Ticket</button>
//         </form>
//       </div>

//       <div className="knowledge-base">
//         <h3>Knowledge Base</h3>
//         <ul>
//           <li><a href="#faq">Frequently Asked Questions</a></li>
//           <li><a href="#billing">Billing Issues Guide</a></li>
//           <li><a href="#outage">Outage Troubleshooting</a></li>
//         </ul>
//       </div>
//     </div>
//   );
// }

// export default Support;



import React, { useState } from 'react';

const initialTickets = [
  { id: 1, user: 'John Doe', issue: 'Bill discrepancy', status: 'Open', priority: 'Medium', lastUpdate: '2023-06-01' },
  { id: 2, user: 'Jane Smith', issue: 'Power outage', status: 'In Progress', priority: 'High', lastUpdate: '2023-06-03' },
  { id: 3, user: 'Bob Johnson', issue: 'Smart meter not responding', status: 'Resolved', priority: 'Low', lastUpdate: '2023-05-28' }
];

function Support() {
  const [tickets, setTickets] = useState(initialTickets);
  const [newTicket, setNewTicket] = useState({ user: '', issue: '', priority: 'Low' });

  const handleInputChange = (e) => {
    setNewTicket({ ...newTicket, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const ticket = { ...newTicket, id: tickets.length + 1, status: 'Open', lastUpdate: '2023-06-04' };
    setTickets([...tickets, ticket]);
    setNewTicket({ user: '', issue: '', priority: 'Low' });
  };

  return (
    <div className="support">
      <h2>Customer Support and Helpdesk</h2>
      
      <div className="ticket-list">
        <h3>Support Tickets</h3>
        <table>
          <thead>
            <tr><th>ID</th><th>User</th><th>Issue</th><th>Status</th><th>Priority</th><th>Last Update</th></tr>
          </thead>
          <tbody>
            {tickets.map(ticket => (
              <tr key={ticket.id}>
                <td>{ticket.id}</td>
                <td>{ticket.user}</td>
                <td>{ticket.issue}</td>
                <td>{ticket.status}</td>
                <td>{ticket.priority}</td>
                <td>{ticket.lastUpdate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="new-ticket">
        <h3>Create New Ticket</h3>
        <form onSubmit={handleSubmit}>
          <input type="text" name="user" placeholder="User Name" value={newTicket.user} onChange={handleInputChange} required />
          <input type="text" name="issue" placeholder="Issue Description" value={newTicket.issue} onChange={handleInputChange} required />
          <select name="priority" value={newTicket.priority} onChange={handleInputChange}>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
          </select>
          <button type="submit">Submit Ticket</button>
        </form>
      </div>

      <div className="knowledge-base">
        <h3>Knowledge Base</h3>
        <ul>
          <li><a href="#faq">Frequently Asked Questions</a></li>
          <li><a href="#billing">Resolving Billing Issues</a></li>
          <li><a href="#outage">Power Outage Guide</a></li>
          <li><a href="#meter">Smart Meter Troubleshooting</a></li>
        </ul>
      </div>
    </div>
  );
}

export default Support;