// import React from 'react';
// import { Bar, Line, Pie } from 'react-chartjs-2';
// import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend, ArcElement, PointElement } from 'chart.js';

// ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend, ArcElement, PointElement);

// function Analytics() {
//   const regions = ['Downtown', 'Suburbs', 'Industrial', 'Commercial'];
//   const usageData = [4200, 3500, 6800, 5300];
//   const monthlyData = [3200, 3800, 4100, 3900, 4500, 5200];
//   const consumerTypes = ['Residential', 'Commercial', 'Industrial'];
//   const consumerData = [60, 25, 15];

//   const barData = {
//     labels: regions,
//     datasets: [{ label: 'Total Usage (kWh)', data: usageData, backgroundColor: 'rgba(54, 162, 235, 0.6)' }]
//   };

//   const lineData = {
//     labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
//     datasets: [{ label: 'Monthly Usage (kWh)', data: monthlyData, borderColor: 'rgb(75, 192, 192)' }]
//   };

//   const pieData = {
//     labels: consumerTypes,
//     datasets: [{ data: consumerData, backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'] }]
//   };

//   return (
//     <div className="analytics">
//       <h2>Data Analytics and Reporting</h2>
      
//       <div className="chart">
//         <h3>Regional Usage</h3>
//         <Bar data={barData} options={{ maintainAspectRatio: false }} />
//       </div>
      
//       <div className="chart">
//         <h3>Monthly Usage Trend</h3>
//         <Line data={lineData} options={{ maintainAspectRatio: false }} />
//       </div>
      
//       <div className="chart">
//         <h3>Consumer Type Distribution</h3>
//         <Pie data={pieData} options={{ maintainAspectRatio: false }} />
//       </div>

//       <div className="metrics">
//         <h3>Key Performance Indicators</h3>
//         <ul>
//           <li>Total Consumption: 19,800 kWh</li>
//           <li>Peak Usage Time: 2 PM - 6 PM</li>
//           <li>Energy Efficiency Score: 82/100</li>
//         </ul>
//       </div>
//     </div>
//   );
// }

// export default Analytics;


import React from 'react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend, ArcElement, PointElement } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, Title, Tooltip, Legend, ArcElement, PointElement);

function Analytics() {
  const regions = ['Downtown', 'Suburbs', 'Industrial', 'Commercial'];
  const usageData = [4200, 3500, 6800, 5300];
  const monthlyData = [3200, 3800, 4100, 3900, 4500, 5200];
  const consumerTypes = ['Residential', 'Commercial', 'Industrial'];
  const consumerData = [60, 25, 15];

  const options = {
    maintainAspectRatio: false,
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: 'Energy Consumption Data' }
    }
  };

  const barData = {
    labels: regions,
    datasets: [{ label: 'Total Usage (kWh)', data: usageData, backgroundColor: 'rgba(54, 162, 235, 0.6)' }]
  };

  const lineData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [{ label: 'Monthly Usage (kWh)', data: monthlyData, borderColor: 'rgb(75, 192, 192)' }]
  };

  const pieData = {
    labels: consumerTypes,
    datasets: [{ data: consumerData, backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'] }]
  };

  return (
    <div className="analytics">
      <h2>Data Analytics and Reporting</h2>
      
      <div className="chart-container">
        <h3>Regional Usage</h3>
        <div style={{ height: '300px' }}>
          <Bar data={barData} options={options} />
        </div>
      </div>
      
      <div className="chart-container">
        <h3>Monthly Usage Trend</h3>
        <div style={{ height: '300px' }}>
          <Line data={lineData} options={options} />
        </div>
      </div>
      
      <div className="chart-container">
        <h3>Consumer Type Distribution</h3>
        <div style={{ height: '300px', maxWidth: '500px', margin: 'auto' }}>
          <Pie data={pieData} options={options} />
        </div>
      </div>

      <div className="metrics">
        <h3>Key Performance Indicators</h3>
        <ul>
          <li>Total Consumption: 19,800 kWh</li>
          <li>Peak Usage Time: 2 PM - 6 PM</li>
          <li>Energy Efficiency Score: 82/100</li>
        </ul>
      </div>
    </div>
  );
}

export default Analytics;