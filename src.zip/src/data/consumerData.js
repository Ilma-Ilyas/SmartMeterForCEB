export const consumerData = [
    {
      meterId: 'SM001',
      name: 'John Doe',
      contact: '(123) 456-7890',
      email: 'john@example.com',
      address: '123 Main St, Anytown, USA',
      consumerType: 'Residential',
      paymentPreference: 'Auto-pay',
      energyUsagePatterns: {
        morningUsage: 'High',
        afternoonUsage: 'Medium',
        eveningUsage: 'High'
      }
    },
    {
      meterId: 'SM002',
      name: 'ABC Corporation',
      contact: '(987) 654-3210',
      email: 'info@abccorp.com',
      address: '456 Business Park, Metropolis, USA',
      consumerType: 'Commercial',
      paymentPreference: 'Net 30',
      energyUsagePatterns: {
        morningUsage: 'Medium',
        afternoonUsage: 'High',
        eveningUsage: 'High'
      }
    },
    {
      meterId: 'SM003',
      name: 'Emma Johnson',
      contact: '(456) 789-0123',
      email: 'emma@example.com',
      address: '789 Oak St, Greenville, USA',
      consumerType: 'Residential',
      paymentPreference: 'Monthly Invoice',
      energyUsagePatterns: {
        morningUsage: 'Low',
        afternoonUsage: 'Medium',
        eveningUsage: 'High'
      }
    }
  ];