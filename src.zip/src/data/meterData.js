export const meterData = [
    { id: 'SM001', region: 'Downtown', status: 'active', location: [37.7749, -122.4194], usage: 7.2 },
    { id: 'SM002', region: 'Downtown', status: 'inactive', location: [37.7749, -122.4180], usage: 0.5 },
    { id: 'SM003', region: 'Mission Bay', status: 'active', location: [37.7785, -122.3892], usage: 12.3 },
    { id: 'SM004', region: 'SoMa', status: 'active', location: [37.7790, -122.4070], usage: 5.8 },
    { id: 'SM005', region: 'Nob Hill', status: 'active', location: [37.7930, -122.4161], usage: 3.1 },
    { id: 'SM006', region: 'Marina', status: 'inactive', location: [37.8037, -122.4368], usage: 0.2 }
  ];